//
//  ViewController.h
//  ButtonTapper3000
//

//  Copyright (c) 2013 Apple Inc. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <SpriteKit/SpriteKit.h>

@interface ViewController : UIViewController

@property (retain) IBOutlet SKView *skView;

@end
