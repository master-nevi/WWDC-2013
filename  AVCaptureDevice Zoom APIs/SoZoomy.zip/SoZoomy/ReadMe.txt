
SoZoomy
=======

This sample illustrates use of the AVCaptureDevice zoom APIs in three situations:

1. Face detection: tap on a face to lock its size, changes in distance will adjust zoom to compensate
2. Setting the zoom factor: moving the slider assigns to the zoom factor directly with linear mapping
3. Meme mode: this triggers automatic zoom in with fast ramp

===========================================================================
Copyright (C) 2013 Apple Inc. All rights reserved.
