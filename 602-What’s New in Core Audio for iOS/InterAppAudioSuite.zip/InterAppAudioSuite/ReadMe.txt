
Inter-App Audio Suite

Inter-App Audio Suite comprises three samples illustrating different aspects of inter-app audio. Please see the individual ReadMe files.


===========================================================================
Copyright (C) 2013 Apple Inc. All rights reserved.
