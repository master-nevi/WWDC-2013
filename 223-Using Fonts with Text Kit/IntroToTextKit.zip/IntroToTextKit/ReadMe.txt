Intro to Text Kit
=================

Sample code to accompany the WWDC 2013 session "Introducing Text Kit."

Demonstrates the flexibility and power of new Text Kit APIs.

This sample should be run on a device rather than in the simulator.

