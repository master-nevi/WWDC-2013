### InterAppAudioDelay ###

Inter-app-audio allows applications to publish themselves so that they can be used in conjunction with other audio applications.
This example illustrates how to publish and control a delay effect, which can be used by another application.


===========================================================================
Copyright (C) 2013 Apple Inc. All rights reserved.
