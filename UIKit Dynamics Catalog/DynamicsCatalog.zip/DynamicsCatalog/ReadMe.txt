
UIKit Dynamics Catalog
======================

This sample illustrates a number of uses of UIKit Dynamics.

There are 8 view controllers, each shows a different way of using UIKit Dynamics.

Known issues: The application may crash when returning to the top view controller from the Attachments and Collision + Gravity + Spring examples. This will be addressed in a future iOS seed.

==================================================
Copyright (C) 2013 Apple Inc. All rights reserved.
