
WWDCMaps

This sample demonstrates how to use the informal UIAccessibility protocol to make an application accessibile.

================================================================================
Copyright (C) 2013 Apple Inc. All rights reserved.

