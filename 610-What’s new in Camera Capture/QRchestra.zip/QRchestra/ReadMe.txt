
QRchestra

QRchestra detects and decodes QR codes using the AVMetadataMachineReadableCodeObject API. If the decoded value is a valid MIDI note number, it plays the note.

===========================================================================
Copyright (C) 2013 Apple Inc. All rights reserved.
