Rock, Paper, Scissors
=====================

Rock, Paper, Scissors is a turn-based game sample, built using Sprite Kit.


**** Important ****

To run and test this sample, you'll need to configure a certificate, identifier, and provisioning profile, configured for the game's bundle identifier with Game Center enabled.

The bundle identifier to use is:
    com.example.apple-samplecode.rockpaperscissors

