//
//  main.m
//  Scene Kit Session WWDC 2013
//
//  Created by Amaury on 30/05/2013.
//  Copyright (c) 2013 Apple Inc. All rights reserved.
//

#import <Cocoa/Cocoa.h>

int main(int argc, const char * argv[])
{
    return NSApplicationMain(argc, argv);
}
