
ButtonTapper3000

This is a small sample game that shows developers how to integrate Game Center with their game. This sample demonstrates how to authenticate a player, and how to implement leaderboards and achievements., as well as the newly added leaderboard display set and most recent score leaderboards. This example also shows how to issue challenges to other players and how to complete specific challenges. 

Note: As of the first seed, Leaderboard Sets do not work in the vended Game Center view Controller, and all leaderboards return no scores, regardless of their actual contents. Both of these issues will be fixed for the second seed.

===========================================================================
Copyright (C) 2013 Apple Inc. All rights reserved.
