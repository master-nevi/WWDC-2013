
InterAppAudioHost

InterAppAudioHost allows iOS audio applications that are remote instruments, effects or generators to publish an output which can be used by other audio applications. These applications which publish an output are known as nodes. Any application which connects and utilizes these node applications is a host. This is an example of a host application.

This example is intended to be used with the node examples InterAppAudioDelay and InterAppAudioSampler.


===========================================================================
Copyright (C) 2013 Apple Inc. All rights reserved.
